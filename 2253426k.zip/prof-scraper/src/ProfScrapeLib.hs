{-# LANGUAGE OverloadedStrings #-}

module ProfScrapeLib
    (  numProfessors
    ) where

import Text.HTML.Scalpel
import Data.Maybe
import Data.List

parseurl name = "https://www.gla.ac.uk/schools/" ++ name ++ "/staff"



numProfessors :: String -> IO (Maybe Int)

numProfessors school = do
  
  page <- scrapeURL (parseurl school) scrapePage
  
  let firstPass =  (fmap (filter (isInfixOf "Professor")) page)
      stageTwo =   fmap (filter (not.isInfixOf "Honorary"))(fmap (filter (not.isInfixOf "Assistant")) firstPass)
      stageFinal = fmap (filter (not.isInfixOf "Associate"))(fmap (filter (not.isInfixOf "Affiliate")) stageTwo)

  return (fmap length (stageFinal))

scrapePage :: Scraper String [String]
scrapePage = 
  chroot ("ul" @: ["id" @= "research-teachinglist"]) scrapeList

scrapeList :: Scraper String [String]
scrapeList =
  texts "li" 